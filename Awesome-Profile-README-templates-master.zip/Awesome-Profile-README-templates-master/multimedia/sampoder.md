<h1 align="left">👋 Welcome to my makerspace!</h3>

<p align="left">
  <a href="https://sampoder.com">Web</a> •
  <a href="https://twitter.com/sam_poder">Twitter</a> •
  <a href="https://instagram.com/sam_poder">Instagram</a>
</p>

| I live in **Singapore**  | I am from **Australia**  |
|---|---|
| <img src ="https://source.unsplash.com/400x400/?marina%20bay,landscape,singapore" width = "200px">  |  <img src ="https://source.unsplash.com/400x400/?sydney,landscape,australia" width = "200px"> |

**🔭 Current Project:** Hack Club Summer of Making

**🌱 Currently Learning:** ReactJS

**🤔 Thinking about:** STEM Education

**📫 Email me:** hi@sampoder.com

**😄 Pronouns:** he/him/his

Here are some random photos from my life:

<img src ="https://github.com/sampoder/sampoder/raw/master/GOPR5263.JPG" height = "200px">  <img src ="https://github.com/sampoder/sampoder/raw/master/IMG_0269.jpg" height = "200px"> <img src ="https://github.com/sampoder/sampoder/raw/master/IMG_20190427_185037401.jpg/" height = "200px">

---
⭐️ From [sampoder](https://github.com/sampoder)