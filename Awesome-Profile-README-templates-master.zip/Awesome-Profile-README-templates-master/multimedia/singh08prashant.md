<h1 align="center">Hi <img src="https://i.pinimg.com/originals/28/02/00/28020003d4a493c78d8202ba6c35f179.gif" width="60px" height="70px">, I'm Prashant Singh
<img src = "https://octodex.github.com/images/spidertocat.png" width ="80px" height="100px"> </h1>
<p align ="left">
<img src="https://github-readme-stats.vercel.app/api?username=singh08prashant&show_icons=true&title_color=00ffff&text_color=33ff33&bg_color=333333&icon_color=ffff4d")
</p>

<img align='right' src='https://media1.tenor.com/images/763645168fe913c18e4d52385e91cccc/tenor.gif?itemid=11550101' height = "200" width="250">

---


<center>   <h2> 𝗠𝘆 𝗧𝗲𝗰𝗸 𝗦𝘁𝗮𝗰𝗸 </h2> </center>

<table>
  <tbody>
    <tr valign="top">
      <td width="25%" align="center">
        <span>𝗛𝗧𝗠𝗟𝟱</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/html-5.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗖𝗦𝗦𝟯</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/css-3.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗝𝗮𝘃𝗮𝗦𝗰𝗿𝗶𝗽𝘁</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/javascript.svg">
      </td>
      <td width="25%" align="center">
        <span> <b>Google Cloud Platform</b></span><br><br><br>
        <img height="128px" src="https://download.logo.wine/logo/Google_Cloud_Platform/Google_Cloud_Platform-Logo.wine.png">
      </td>
    </tr>
    <tr valign="top">
      <td width="25%" align="center">
         <span><b>Tensorflow 2.0</b></span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/tensorflow.svg">
      </td>
      <td width="25%" align="center">
        <span><b>Python 3</b></span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/python.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗚𝗶𝘁</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/git-icon.svg">
      </td>
      <td width="25%" align="center">
        <span>𝗩𝗦 𝗖𝗼𝗱𝗲</span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/visual-studio-code.svg">
      </td>
    </tr>
  </tbody>
</table>
</p>

<hr>

### 📝 Latest articles from [dev.to](https://dev.to/singh08prashant)

* Jul 11 2020 [Building & Deploying an Image Classification Web App with GCP AutoML Vision Edge, Tensorflow.js & GCP App Engine](https://dev.to/singh08prashant/building-deploying-an-image-classification-web-app-with-gcp-automl-vision-edge-tensorflow-js-gcp-app-engine-57gb) 

<p align = "center">
 <a href="https://twitter.com/s08prashant">
  <img align="center" alt="Prashant's Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />
</a>
<a href="https://www.linkedin.com/in/prashant-singh-08/">
  <img align="center" alt="Prashant's's Linkdein" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>
<a href="https://github.com/singh08prashant">
  <img align="center" alt="Prashant's Github" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/github.svg" />
</a>
<a href="https://t.me/s08prashant">
  <img align="center" alt="Prashant's Telegram" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/telegram.svg" />
</a>
<a href="https://www.hackerrank.com/singh08prashant">
  <img align="center" alt="Prashant's Hackerrank" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/hackerrank.svg" />
</a>

</p>

<p align="center">

<img src="https://img.shields.io/badge/dynamic/json?color=brightgreen&label=followers&query=followers&url=https%3A%2F%2Fapi.github.com%2Fusers%2Fsingh08prashant" />
<img src="https://komarev.com/ghpvc/?username=singh08prashant" alt="singh08prashant" />

</p>

⭐️ From [singh08prashant](https://github.com/singh08prashant)
