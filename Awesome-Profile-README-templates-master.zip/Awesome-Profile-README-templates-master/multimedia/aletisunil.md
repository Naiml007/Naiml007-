


<p align="center"><img src="https://github.com/aletisunil/aletisunil/blob/master/IMG_0288.gif" /></p>



<hr>
<p align="center">
  <i><b>Let's connect and chat!</b></i>

  <p align="center">
    <a href="https://twitter.com/aleti_sunil" alt="Twitter"><img src="https://github.com/aletisunil/aletisunil/blob/master/twitter.png" height="30" width="30"></a>&nbsp;
    <a href="https://www.linkedin.com/in/sunilaleti/" alt="Linkedin"><img src="https://github.com/aletisunil/aletisunil/blob/master/linkedin.png" height="30" width="30"></a>&nbsp;
    <a href="https://www.instagram.com/sunil_aleti" alt="Instagram"><img src="https://github.com/aletisunil/aletisunil/blob/master/instagram.png" height="30" width="30"></a>&nbsp;
     <a href="https://t.me/sunilaleti" alt="Telegram"><img src="https://github.com/aletisunil/aletisunil/blob/master/telegram.png" height="30" width="30"></a>&nbsp;
    <a href="https://dev.to/aletisunil"><img src="https://d2fltix0v2e0sb.cloudfront.net/dev-badge.svg" height="30" width="30"></a>&nbsp;
    <a href="https://aletisunil.github.io/"><img src="https://github.com/aletisunil/aletisunil/blob/master/globe.png" height="30" width="30"></a>

  </p>
    
</p>
