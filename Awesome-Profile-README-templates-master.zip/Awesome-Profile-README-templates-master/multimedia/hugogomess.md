<h1 align= "center"><b>Hi, i'm Hugo!</b></h1>
<p align="center"><img width="350" heigh="190" src="https://github.com/hugogomess/hugogomess/blob/master/hacking.gif"></p>

I'm Hugo, a 20 years old full-stack web developer from Brazil, backend is my favorite part of software development and i like work with languages like javascript and python. I'm an ethical hacking enthusiast and probability in the future i will try to work with cyber security. I'm a Capture The Flag (CTF) player in my free time too...

If you want to know more about me and see my projects access [hugogomess.github.io](https://hugogomess.github.io/)

- Portfolio: [hugogomess.github.io](https://hugogomess.github.io/)
- Email: [hugogomes02@gmail.com](mailto:hugogomes02@gmail.com)
- Linkedin: [hugogomess](https://www.linkedin.com/in/hugogomess/)
- Medium: [hugogomess](https://medium.com/@hugogomess)

⭐️ From [hugogomess](https://github.com/hugogomess)
