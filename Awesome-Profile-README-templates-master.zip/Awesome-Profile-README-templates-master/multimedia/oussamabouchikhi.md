### Hi there, I'm Oussama 👋

<div align="center">
  <img width="100%" src="https://github.com/oussamabouchikhi/oussamabouchikhi/blob/master/assets/cover.png" alt="cover" />
</div>


<table>
  <thead>
    <tr>
      <td align="center">
        <span><strong>Programming Languages & Frameworks</strong></span>
      </td>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td align="center">
        <img width="70%" src="https://github.com/oussamabouchikhi/oussamabouchikhi/blob/master/assets/skills.png" alt="cover" />
      </td>
    </tr>
  </tbody>

</table>
</div>

## About me
I am Oussama Bouchikhifrom Algeria, I'm a computer science student a full stack web developer and an open source enthusiast. I like programming , design, photography and I always want to learn new things.

<h2><i>Follow me:</i></h2>
<div  align="center">

  <a href="https://www.linkedin.com/in/oussama-bouchikhi-49a0b6193/" target="_blank">
    <img src="https://img.shields.io/badge/LinkedIn-%230077B5.svg?&style=flat-square&logo=linkedin&logoColor=white&color=071A2C" alt="LinkedIn">
  </a>
  <a href="https://www.instagram.com/ousstheboss/" target="_blank">
    <img src="https://img.shields.io/badge/Instagram-%23E4405F.svg?&style=flat-square&logo=instagram&logoColor=white&color=071A2C" alt="Instagram">
  </a>
  <a href="https://www.facebook.com/oussama.bouchikhi.98" target="_blank">
    <img src="https://img.shields.io/badge/Facebook-%231877F2.svg?&style=flat-square&logo=facebook&logoColor=white&color=071A2C" alt="Facebook">
  </a>

 <a href="https://twitter.com/oussth3boss/" target="_blank">
    <img src="https://img.shields.io/badge/Twitter-%231877F2.svg?&style=flat-square&logo=twitter&logoColor=white&color=071A2C" alt="Twitter">
  </a>
   <a href="mailto:oussamabouchikhi700@gmail.com" mailto="oussamabouchikhi700@gmail.com" target="_blank">
    <img src="https://img.shields.io/badge/Gmail-%231877F2.svg?&style=flat-square&logo=gmail&logoColor=white&color=071A2C" alt="Gmail">
  </a>
  <a href="https://www.freelancer.com/u/oussamabouchikhi" target="_blank">
    <img src="https://img.shields.io/badge/Freelancer-%231877F2.svg?&style=flat-square&logo=freelancer&logoColor=white&color=071A2C" alt="Freelancer">
  </a>
  <a href="https://twitter.com/oussth3boss/" target="_blank">
    <img src="https://img.shields.io/badge/Upwork-%231877F2.svg?&style=flat-square&logo=upwork&logoColor=white&color=071A2C" alt="Upwork">
  </a>
<a href="https://www.fiverr.com/oussama700" target="_blank">
    <img src="https://img.shields.io/badge/Fiver-%231877F2.svg?&style=flat-square&logo=fiver&logoColor=white&color=071A2C" alt="Upwork">
  </a>
</div>
<hr>
⭐️ From <a href="https://github.com/oussamabouchikhi">oussamamabouchikhi</a>
