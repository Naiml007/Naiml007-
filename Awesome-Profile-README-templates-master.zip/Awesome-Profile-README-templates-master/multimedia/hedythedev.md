<img src="https://raw.githubusercontent.com/hedythedev/hedythedev/master/assets/hedylibanner.png" alt="Hey, I'm Hedy [banner]" />
<!--
How did I make the fabulous banner?
Well, I did it using canva.com, nothing fancy completely free :)
-->

<!--
<h1 align="center">Sup everyone! 👋</h1>
-->
<p align="center"> <img src="https://komarev.com/ghpvc/?username=hedythedev" alt="hedythedev" /> <img src="https://img.shields.io/badge/Pronouns-She%2FHer-green" alt="pronouns: she/her" /> </p>
<!--
The above contains two badges, one is profile views count, and the other
one is "pronouns" info from shields.io
-->

<p align="center"><img src="https://devicons.github.io/devicon/devicon.git/icons/python/python-original.svg" alt="python" width="45" height="45"/> <img src="https://devicons.github.io/devicon/devicon.git/icons/javascript/javascript-original.svg" alt="javascript" width="45" height="45"/><img src="https://devicons.github.io/devicon/devicon.git/icons/react/react-original-wordmark.svg" alt="react" width="45" height="45"/> <img src="https://devicons.github.io/devicon/devicon.git/icons/nodejs/nodejs-original-wordmark.svg" alt="nodejs" width="45" height="45"/><img src="https://devicons.github.io/devicon/devicon.git/icons/html5/html5-original-wordmark.svg" alt="html5" width="45" height="45"/> <img src="https://devicons.github.io/devicon/devicon.git/icons/java/java-original-wordmark.svg" alt="java" width="45" height="45"/>  </p>
<!--
The above are the languages/technologies icons from devicons :)
-->

<p align="center">
<a href="https://dev.to/hedyli" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/dev-dot-to.svg" alt="hedyli" height="20" width="20" /></a>
<a href="https://twitter.com/hedythedev" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/twitter.svg" alt="hedythedev" height="20" width="20" /></a>
<a href="https://linkedin.com/in/hedy-li-8608831a6" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg" alt="hedy-li-8608831a6" height="20" width="20" /></a>
<a href="https://stackoverflow.com/users/12041035/hedy" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/stackoverflow.svg" alt="hedy" height="20" width="20" /></a>
</p>
<!--
These are my social profile links/icons
-->

<br/>

- 🔭 I’m currently working on  **[starcli](https://github.com/hedythedev/starcli)**
- 📫 How to reach me (use one of the following ways):
   1. **[twitter @hedythedev](https://twitter.com/hedythedev) (recommended)**
   2. **[linkedin](https://www.linkedin.com/in/hedy-li-8608831a6/) (if you don't have twitter)**
   3. **[email](mailto:hedyhyry+hey@gmail.com) (not recommended)**
- ⚡ Fun facts: 
   1. I speak fluent Chinese 💯
   2. I *try* to live entirely in the terminal :computer:
   3. Favorite emoji: :smirk: (the *smirk*)


<!-- My GitHub stats with Dracula theme ❤️ -->
<p align="center">
<img src="https://github-readme-stats.vercel.app/api?username=hedythedev&show_icons=true&theme=dracula" alt="my github stats" width="450"/>
</p>

---
### :zap: Recent Activity
<!--START_SECTION:activity-->
1. ❗️ Opened issue [#1](https://github.com//hedythedev/open-sauced-goals/issues/1) in [hedythedev/open-sauced-goals](https://github.com//hedythedev/open-sauced-goals)
2. 🗣 Commented on [#61](https://github.com//hedythedev/starcli/issues/61) in [hedythedev/starcli](https://github.com//hedythedev/starcli)
3. 🗣 Commented on [#68](https://github.com//hedythedev/starcli/issues/68) in [hedythedev/starcli](https://github.com//hedythedev/starcli)
4. 🎉 Merged PR [#67](https://github.com//hedythedev/starcli/pull/67) in [hedythedev/starcli](https://github.com//hedythedev/starcli)
5. 🗣 Commented on [#2](https://github.com//iqubex-technologies/pkgreview.dev/issues/2) in [iqubex-technologies/pkgreview.dev](https://github.com//iqubex-technologies/pkgreview.dev)
<!--END_SECTION:activity-->
---

<!-- Feel free to reach out and introduce yourself :D-->
<img src="https://media.giphy.com/media/LnQjpWaON8nhr21vNW/giphy.gif" width="60"> <em><b>I love connecting with different people from around the world, so if you want to be my friend, feel free to <a href="https://twitter.com/hedythedev">reach out</a> and introduce yourself (don’t just say hi, tell me about yourself)</b> 😊 💜</em>

<!--The End, special thanks to all the wonderful people who made
the GitHub profile readme stats/workflows to make my profile look
fabulously dynamic ❤️-->

:star: from [hedythedev](https://github.com/hedythedev)
