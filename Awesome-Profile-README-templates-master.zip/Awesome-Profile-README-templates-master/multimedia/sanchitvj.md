<p  align="center"><img height="400" src = "https://github.com/sanchitvj/sanchitvj/blob/master/intro_gif.gif"></p>  

**Here are some ideas to get you started:**

- 🔭 I’m currently working on Deep Learning Computer Vision.
- 🌱 I’m currently learning Natural Language Processing.
- 👯 I’m looking to collaborate on Kaggle projects.
- 🤔 I’m looking for help with Neural Style Transfer.
- 📫 How to reach me: sanchitvj1026@gmail.com
- 😄 Pronouns: Anything you like.
- ⚡ Fun fact: Undergrad in ECE but don't know why I chose that.  

![](https://github-readme-stats.vercel.app/api?username=sanchitvj&show_icons=true&title_color=E88795&icon_color=FF33FF&text_color=D6BCD5&bg_color=151515)
  
 
**You can find me here:**  
|  <a><img src="https://icon-library.net//images/icon-programmer/icon-programmer-14.jpg" width="150px" height="150px" /></a> |
|:---------------------------------------------------------------------------------------------------------------------------------------: |
|<a href="https://www.linkedin.com/in/sanchit-vijay-774432178"><img src="https://github.com/hussainweb/hussainweb/blob/main/icons/linkedin.png" width="32px" height="32px"></a>
<a href="https://medium.com/@sanchitvj"><img src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/medium.svg" width="32px" height="32px"></a>
<a href="https://www.kaggle.com/sanchitvj"><img src="https://cdn4.iconfinder.com/data/icons/logos-and-brands/512/189_Kaggle_logo_logos-512.png" width="32px" height="32px"></a>
<a href="https://mobile.twitter.com/sanchit_vijay"><img src="https://github.com/hussainweb/hussainweb/blob/main/icons/twitter.png" width="32px" height="32px"></a>|
  

<br>**Visitors Count**  
![VisitorCount](https://profile-counter.glitch.me/{sanchitvj}/count.svg)

⭐ From [sanchitvj](https://github.com/sanchitvj)
