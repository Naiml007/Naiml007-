<h1 align="center">Hi 👋, I'm Salman</h1>
<h3 align="center">A Fascinated Coder & Blockchain Developer</h3>
<p align="left"> <img src="https://komarev.com/ghpvc/?username=salmandabbakuti" alt="salmandabbakuti" /> </p>

- 🔭 I’m currently working on **Blockchain and Cloud Computing**

- 👯 I’m looking to collaborate on **Opensource Blockchain Projects**

- 👨‍💻 All of my projects are available at [https://salmandabbakuti.github.io](https://salmandabbakuti.github.io)

- 📝 I regulary write articles on [https://medium.com/@Salmandabbakuti](https://medium.com/@Salmandabbakuti)

- 💬 Ask me about **Blockchain Stuffs**

- 📫 How to reach me **dabbakuti.salman@gmail.com**

- ⚡ Fun fact **I know all Programming Memes🤩**

<p align="center">
<img src="https://www.vectorlogo.zone/logos/hyperledger/hyperledger-icon.svg" alt="hyperledger" width="40" height="40"/>
<img src="https://devicons.github.io/devicon/devicon.git/icons/amazonwebservices/amazonwebservices-original-wordmark.svg" alt="amazonwebservices" width="40" height="40"/>
  <img src="https://status.xooa.com/kt6Eed6xNvSV" alt="xooa" width="45" height="20"/>
<img src="https://www.vectorlogo.zone/logos/ethereum/ethereum-icon.svg" alt="ethereum" width="40" height="40"/>
<img src="https://devicons.github.io/devicon/devicon.git/icons/nodejs/nodejs-original-wordmark.svg" alt="nodejs" width="40" height="40"/>
<img src="https://devicons.github.io/devicon/devicon.git/icons/javascript/javascript-original.svg" alt="javascript" width="20" height="20"/>
<img src="https://devicons.github.io/devicon/devicon.git/icons/docker/docker-original-wordmark.svg" alt="docker" width="20" height="20"/>
<img src="https://devicons.github.io/devicon/devicon.git/icons/mongodb/mongodb-original-wordmark.svg" alt="mongodb" width="40" height="30"/>
<img src="https://devicons.github.io/devicon/devicon.git/icons/go/go-original.svg" alt="go" width="20" height="20"/><img src="https://devicons.github.io/devicon/devicon.git/icons/python/python-original-wordmark.svg" alt="python" width="40" height="40"/>
<img src="https://devicons.github.io/devicon/devicon.git/icons/bootstrap/bootstrap-plain.svg" alt="bootstrap" width="20" height="20"/> <img src="https://devicons.github.io/devicon/devicon.git/icons/css3/css3-original-wordmark.svg" alt="css3" width="20" height="20"/><img src="https://devicons.github.io/devicon/devicon.git/icons/html5/html5-original-wordmark.svg" alt="html5" width="20" height="20"/></p><p align="center"> <img src="https://github-readme-stats.vercel.app/api?username=salmandabbakuti&show_icons=true" alt="salmandabbakuti" /> </p>

<p align="center">
  <a href="https://in.linkedin.com/in/salman-dabbakuti-400479135" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg" alt="salmandabbakuti" height="20" width="20" /></a>
<a href="https://dev.to/salmandabbakuti" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/dev-dot-to.svg" alt="salmandabbakuti" height="20" width="20" /></a>
<a href="https://twitter.com/salmandabbakuti" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/twitter.svg" alt="salmandabbakuti" height="20" width="20" /></a>
<a href="https://fb.com/dabbakuti.salmon" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/facebook.svg" alt="dabbakuti.salmon" height="20" width="20" /></a>
<a href="https://medium.com/@Salmandabbakuti" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/medium.svg" alt="salmandabbakuti" height="20" width="20" /></a>
</p>

<!-- Note: Some logos I've used here are a trademark logos of the respective Companies.-->

⭐ From [Salman Dabbakuti](https://github.com/Salmandabbakuti)
