<h1 align="center" > Hi, I am Hayat Tamboli 👋</h1>

![hello world](https://github.com/hayat-tamboli/hayat-tamboli/raw/master/hello-world.png)

<hr/>

<div align="center">


[![Hayat's github stats](https://github-readme-stats.vercel.app/api?username=hayat-tamboli&show_icons=true&title_color=2257EA&icon_color=2257EA&bg_color=f7f7f7)](https://github.com/anuraghazra/github-readme-stats)
[![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=hayat-tamboli&title_color=2257EA&bg_color=f7f7f7&hide=html,css)](https://github.com/anuraghazra/github-readme-stats)

</div>


I am a computer science undergrad from Solapur, Maharashtra. Currently I am studying in VIT Vellore. I am very passionate about __web design__ and __frontend web development__

## 🔗 Connect with me on :

[![Connect on LinkedIn](https://img.shields.io/badge/--website?label=My%20Website&logo=awesome-lists&style=social&logoColor=2257ea)](https://hayattamboli.vercel.app/)
[![Connect on LinkedIn](https://img.shields.io/badge/--linkedin?label=LinkedIn&logo=LinkedIn&style=social)](https://www.linkedin.com/in/hayat-tamboli/)
[![Follow on Twitter](https://img.shields.io/badge/--twitter?label=Twitter&logo=Twitter&style=social)](https://twitter.com/HayatTamboli)

### 👀 visitor count

<img src="https://profile-counter.glitch.me/hayat-tamboli/count.svg" alt="Hello world" />

<hr />


⭐ From [Hayat Tamboli](https://github.com/hayat-tamboli)