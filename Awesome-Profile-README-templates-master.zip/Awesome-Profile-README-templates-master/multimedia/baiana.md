
![](https://user-images.githubusercontent.com/18560467/90992251-de862b00-e584-11ea-96df-3c2fad82807b.gif)


![githubbadge](https://img.shields.io/github/followers/baiana?style=social) <a href="https://www.linkedin.com/in/ana-souza-dias/"><img alt="LinkedIn" src="https://img.shields.io/badge/LinkedIn-Ana%20Luisa%20Dias-blue?style=flat&logo=linkedin"></a> [![Instagram Badge](https://img.shields.io/badge/-anabaiana__-purple?&logo=instagram&logoColor=white&link=[https://www.instagram.com/anabaiana_/](https://www.instagram.com/anabaiana_/))](https://instagram.com/anabaiana_)

Welcome to my Github! I make some fun codes to learn new things and help other people learn it too (especially from my mistakes :sweat_smile:).

### :star: Some fun facts!
- I love Doctor Who, The Umbrella Academy and Star Wars;
 - I'm left handed  :point_left: 
 - This drawing of me was a gift from my friend [@blueIlustra](https://www.instagram.com/blueilustra/) :heart: 

##  :calendar: I'm currently  ...

### :bar_chart: working:

 - At [Delivery Much Brasil](https://www.linkedin.com/company/delivery-much-brasil/) as Android Developer;
 - Using ![Kotlin](https://img.shields.io/badge/-kotlin-006a71?&logo=kotlin) ![GitHub](https://img.shields.io/badge/-GitHub-181717?&logo=github) ![](https://img.shields.io/badge/-Git-black?style=plastic&logo=git) ![enter image description here](https://img.shields.io/badge/-Android-3e9e06?&logo=android) ![enter image description here](https://img.shields.io/badge/-gitflow-05a698?&logo=git);
 
 ### :books: Learning:
 - ![enter image description here](https://img.shields.io/badge/-Flutter-5dcede?&logo=flutter) ![enter image description here](https://img.shields.io/badge/-Dart-0d91a3?&logo=dart) ![enter image description here](https://img.shields.io/badge/-Swift-964b09?&logo=swift), android animations, game development, CI/CD, UI testing;
 - ![enter image description here](https://img.shields.io/badge/-Python-780723?&logo=python) with the Pyladies Study Group :heart:
 - how to Sew, crochet, embroider and knitt; 
 - Something new everyday! 

### :mortar_board: Graduating:
Science and Technology interdisciplinary bachelor, in UFBA (Federal University of Bahia) with the intend to pursue a Computer Science degree after!

## :speech_balloon: And I also...
Can help with your open source project, connect you with great tech communities and recommend great materials about diversity and inclusion! 🎉

Let's talk! 

⭐️ From [Baiana](https://github.com/baiana)
