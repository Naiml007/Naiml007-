<p align='center'>
  <a href="https://github.com/jain-mukesh"><img height="30" src="https://img.shields.io/badge/-jain--mukesh-black?logo=github&style=flat-square"></a>&nbsp;&nbsp;
  <a href="https://www.linkedin.com/in/jain-mukesh"><img height="30" src="https://img.shields.io/badge/-jain--mukesh-blue?logo=linkedin&style=flat-square"></a>&nbsp;&nbsp;
  <a href="mailto:jainmukesh@gmail.com"><img height="30" src="https://img.shields.io/badge/-jainmukesh@gmail.com-black?logo=gmail&style=flat-square"></a>&nbsp;&nbsp;
    <a href="https://twitter.com/_mjain"><img height="30" src="https://img.shields.io/badge/-__mjain-blue?logo=twitter&style=flat-square"></a>&nbsp;&nbsp;
  <a href="https://medium.com/@jainmukesh"><img height="30" src="https://img.shields.io/badge/-@jainmukesh-black?logo=medium&style=flat-square"></a>
</p>

### On my blog
<!-- blog starts -->
* [Analyzing Failure: A Step by Step Approach](https://medium.com/@nimish.jain_21547/analyzing-failure-a-step-by-step-approach-e430047995f4) - 2020-07-06
* [New Perspectives](https://medium.com/@jainmukesh/new-perspectives-72516b150a9) - 2020-06-15
* [Slow Browser? 1 Hack to speed it up](https://medium.com/@jainmukesh/slow-browser-1-hack-to-speed-it-up-2c6d90152b7b) - 2020-06-01
* [Desires and Happiness](https://medium.com/@jainmukesh/desires-and-happiness-7a19f737684e) - 2019-02-08
<!-- blog ends -->
</td><td valign="top">

### Recent releases
<!-- recent_releases starts -->
* [NetSNMP Memory Leak Fix](https://github.com/net-snmp/net-snmp/pull/78) - 2020-03-02
* [Awesome C++ Libraries](https://github.com/jain-mukesh/cpp-tools) - 2019-03-25
* [Ankit's Wedding Website](https://github.com/jain-mukesh/ankit-wedding) - 2019-04-05
<!-- recent_releases ends -->
</td></tr></table>

<!-- [![GitHub](https://github-readme-stats.vercel.app/api?username=jain-mukesh)](https://github.com/jain-mukesh) -->

<a href="https://github.com/jain-mukesh/jain-mukesh/actions"><img src="https://github.com/jain-mukesh/jain-mukesh/workflows/Build%20README/badge.svg" align="right" alt="Build README"></a>

⭐️ From [Mukesh Jain](https://github.com/jain-mukesh)
