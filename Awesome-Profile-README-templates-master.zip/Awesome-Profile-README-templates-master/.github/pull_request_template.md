The markdown file must fulfill these conditions:

- [ ] The name of the readme file is your **username.md** if you are making a new creative readme.
- [ ] The name of the readme file is the person's username from where it is inspired from.
- [ ] The bottom of the readme file contains: `⭐️ From [username](https://github.com/[username])`
