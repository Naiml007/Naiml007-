# Sakshi Gupta
- 📫 Reach me: 
- [twitter.com/Sakshi_0612](https://twitter.com/Sakshi_0612)
- [linkedin.com/in/sakshigupta06](https://www.linkedin.com/in/sakshigupta06/)
- [hashnode.com/@sakshi](https://sakshi.hashnode.dev/)

## Hii👋, 
I'm Sakshi Gupta, final year undergraduate student. I am passionate about technologies and open source. I am a Python Developer.


- 🔭 I’m currently working on Web Development
- 🌱 I’m currently learning Data Structures and Algorithms
- 💬 Hobbies : Reading and Writing Blogs
-  ⚡ Languages: Python3, Java


---

⭐️ From [Sakshi Gupta](http://www.github.com/sakshigupta06)
