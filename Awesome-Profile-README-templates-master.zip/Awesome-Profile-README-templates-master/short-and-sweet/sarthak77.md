<p align="center">
  <img src="https://media.giphy.com/media/QHE5gWI0QjqF2/giphy.gif" width="40%" align="right">
  <br><br>
  <samp>
    Hey!! I'm Sarthak Singhal :wave:
    <br><br>
    I work as a Web :globe_with_meridians: developer!
  </samp>
</p>

<p align="center"> 
  <i> Let's connect and chat! :incoming_envelope: </i>
</p>

<p align="center">
<a href="https://www.linkedin.com/in/sarthak77"><img src="https://github.com/sarthak77/sarthak77/blob/master/icons/icons8-linkedin-circled-48.png" alt="LinkedIn"></a> &nbsp; &nbsp;
<a href="https://www.instagram.com/sarthak02singhal/"><img src="https://github.com/sarthak77/sarthak77/blob/master/icons/icons8-instagram-48.png" alt="Instagram"></a> &nbsp; &nbsp;
<a href="https://www.facebook.com/sarthak.singhal.98434"><img src="https://github.com/sarthak77/sarthak77/blob/master/icons/icons8-facebook-48.png" alt="Facebook"></a> &nbsp; &nbsp;
<a href="mailto:sarthak02singhal@gmail.com"><img src="https://github.com/sarthak77/sarthak77/blob/master/icons/icons8-gmail-48.png" alt="Gmail"></a> &nbsp; &nbsp;
</p>

<!--https://icons8.com/icons/set/svg-->

⭐️ From [sarthak77](https://github.com/sarthak77)
