# Hi there, I'm Victor Barros! 👋

<h3>Passionate about entrepreneurship, technology and economics.</h3>

- 🌱 currently learning software architecture, TDD and ReactJs

<a href="https://www.linkedin.com/in/victor-almeida-barros/?locale=en_US">
  <img width="400px" src="https://raw.githubusercontent.com/victorabarros/victorabarros/master/assets/linkedin_profile.png" />
</a>


<a href="https://github.com/victorabarros?tab=repositories">
  <img width="500px" src="https://github-readme-stats.anuraghazra1.vercel.app/api/top-langs/?username=victorabarros&count_private=true&layout=compact&hide=makefile,shell&hide_title=true&hide_border=true" />
</a>

⭐️ From [victorabarros](https://github.com/victorabarros/victorabarros)
