

![profile-image](https://i.ibb.co/6Z8WqXd/Screenshot-153.png)

#### I'm from Lagos, Nigeria, I try to write code 💻 and solve problems .


### Skills: Dart (Flutter), Javascript (Node), Python .

- 🔭 I’m currently working on Flutter apps
- 🌱 I’m currently learning Dart & Flutter
- 👯 I’m looking to collaborate on open source projects.
- ⚡ Fun fact: I was the Headboy at my High School
- 📫 How to reach me: [olumidenwosu@gmail.com](mailto:olumidenwosu@gmail.com)
- 😄 Pronouns: He/Him

[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg' alt='linkedin' height='30'>](https://www.linkedin.com/in/nwosu-olumide-b7941318b/) [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/twitter.svg' alt='twitter' height='30'>](https://twitter.com/olumidenwosu) [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/github.svg' alt='github' height='30'>](https://github.com/olumidayy) [<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/telegram.svg' alt='telegram' height='30'>](https://t.me/olumidayy)

![GitHub stats](https://github-readme-stats.vercel.app/api?username=olumidayy&show_icons=true)

![Profile views](https://gpvc.arturio.dev/olumidayy)

⭐️ From [olumidayy](https://github.com/olumidayy)

<!--
- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- ⚡ Fun fact: ...
-->
