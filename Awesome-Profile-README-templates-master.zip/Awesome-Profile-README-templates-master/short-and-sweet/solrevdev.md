### John Smith (solrevdev) :wave:

- 🔭 A C#, .NET Core and ASP.NET Core software developer.
- 🇬🇧 Based in Oxford UK
- 🏠 https://solrevdev.com

### Get in touch 📧

- [Twitter](https://twitter.com/solrevdev)
- [LinkedIn](https://www.linkedin.com/in/solrevdev)
- [Website](https://solrevdev.com/about/)

⭐️ From [solrevdev](https://github.com/solrevdev)
