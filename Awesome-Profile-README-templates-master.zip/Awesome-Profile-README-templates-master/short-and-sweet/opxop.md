<div align="center">

  ### Hi there, welcome to my Github! <img src="https://github.com/ABSphreak/ABSphreak/blob/master/gifs/Hi.gif" width="30px">
  ![github stats](https://github-readme-stats.vercel.app/api?username=opxop&show_icons=true)
  
</div>  

<div align="center">
  
  **📫 Reach me at:**<br>

  [![Twitter Badge](https://img.shields.io/badge/-Twitter-1ca0f1?style=flat-square&labelColor=1ca0f1&logo=twitter&logoColor=white&link=https://twitter.com/opakholis)](https://twitter.com/opakholis)
  [![Linkedin Badge](https://img.shields.io/badge/-LinkedIn-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/opakholis/)](https://www.linkedin.com/in/opakholis)
  [![Facebook  Badge](https://img.shields.io/badge/Facebook-%231877F2.svg?&style=flat-square&logo=facebook&logoColor=white)](https://facebook.com/opakholis)
  [![Spotify Badge](https://img.shields.io/badge/Spotify-%231ED760.svg?&style=flat-square&logo=spotify&logoColor=white)](https://open.spotify.com/user/xil3nxol9wadm6lgyw5qv1l2h?si=QDNUS80iR4C97B-tQVLJDw)

</div>

⭐️ From [opxop](https://github.com/opxop)
