Hi there 👋
<p align="left"> <img src="https://komarev.com/ghpvc/?username=rubal-mb" alt="rubal-mb" /> </p>

I am a Computer Science Student, currently in pre final year student at SSIPMT, Raipur

- 🌱 I’m currently learning Data Structure, AI
- 🤔 I’m looking for creating a projects in python 


- 📫 How to reach me: [![Linkedin Badge](https://img.shields.io/badge/-LinkedIn-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/rubal-agrawal/)](https://www.linkedin.com/in/rubal-agrawal/) , [![Gmail Badge](https://img.shields.io/badge/-Gmail-c14438?style=flat-square&logo=Gmail&logoColor=white&link=mailto:rubalagrawalru@gmail.com.com)](mailto:rubalagrawalru@gmail.com)


* From [rubal-mb](https://github.com/rubal-mb)