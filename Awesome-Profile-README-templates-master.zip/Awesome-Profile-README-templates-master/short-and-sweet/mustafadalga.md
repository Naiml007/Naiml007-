<table>
  <tr>
    <td>
      <h1> Who I Am ? </h1>
      <b>A passionate developer who wants to be a pioneer at what he is doing.</b>
      <ul>
        <li>Software Developer - Free Software and Open Source Developer</li>
        <li>Nature and Animal Photographer at <a href="https://instagram.com/dogaklani" alt="Doğa Klanı">Doğa Klanı </a></li>
        <li>Cyber Security Enthusiast</li>
        <li>Book Buff <a href="https://goodreads.com/mustafadalga" alt="Good Reads">Good Reads</a></li>
      </ul>  
     <h2> Communication </h2>
        <p float="left">
  
  [![linkedin](https://user-images.githubusercontent.com/25087769/87172072-530a5080-c2dc-11ea-8e2c-8ee4dbf3394b.png)](https://www.linkedin.com/in/mustafadalga) &nbsp;&nbsp;
  [![website](https://user-images.githubusercontent.com/25087769/87173861-0aa06200-c2df-11ea-9614-da65c9c73692.png)](https://apierson.com) &nbsp;&nbsp;
  [![github](https://user-images.githubusercontent.com/25087769/87176037-2c4f1880-c2e2-11ea-8a13-41c90b711b9f.png)](https://github.com/mustafadalga) &nbsp;&nbsp;
  [![gitlab](https://user-images.githubusercontent.com/25087769/87174063-54894800-c2df-11ea-9620-b2fbf36c3e34.png)](https://gitlab.com/mustafadalga) &nbsp;&nbsp;
  [![codepen](https://user-images.githubusercontent.com/25087769/87174133-6cf96280-c2df-11ea-9134-09bacdfb3464.png)](https://codepen.io/mustafadalga) &nbsp;&nbsp;
  [![twitter](https://user-images.githubusercontent.com/25087769/87172407-de83e180-c2dc-11ea-9479-a894758266c3.png)](https://www.twitter.com/mustafadalgaa) &nbsp;&nbsp;
  [![email](https://user-images.githubusercontent.com/25087769/87174308-a4680f00-c2df-11ea-90b0-5fa1fa76d2f1.png)](mailto:mustafadalgaa@gmail.com)
 
</p>
      </td>   
     <td>
      <img src="https://user-images.githubusercontent.com/25087769/87176682-1f7ef480-c2e3-11ea-9b1d-076f2c8568b2.jpg" width="500">
     </td>
   </tr>
</table>

⭐️ From [mustafadalga](https://github.com/mustafadalga)
