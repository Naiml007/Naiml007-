### HEY visitor :wave:

I am a computer science engineering student who is interested in AI and Machine Learning as well as Data Science. Also in every new technology that is making our lives easier!
- 🔭 I’m currently working on Computer Vision and NLP.
- 🌱 I’m currently learning Data Structures and Algorithms
- 👯 I’m looking to collaborate on a tech project integrating IoT and Machine Learning
- ⚡ Fun question: Do you think machine learning would be that revolutionary if stereotypes didn't exist? :thinking:

 Reach out to me on :point_right: [![Linkedin Badge](https://img.shields.io/badge/-Linkedin-4169E1?style=flat-square&logo=Linkedin&logoColor=white&&link=https://www.linkedin.com/in/vividha-rawat-761905143/)](https://www.linkedin.com/in/vividha-rawat-761905143/)
[![Medium Badge](https://img.shields.io/badge/-Medium-000?style=flat-square&logo=Medium&logoColor=white&&link=https://medium.com/@rvividha)](https://medium.com/@rvividha)
[![Gmail Badge](https://img.shields.io/badge/-Gmail-c14438?style=flat-square&logo=Gmail&logoColor=white&link=mailto:rvividha@gmail.com)](mailto:rvividha@gmail.com)

<!--
**V2dha/V2dha** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

![Vividha's github stats](https://github-readme-stats.vercel.app/api?username=V2dha&show_icons=true&title_color=fff&icon_color=FFD700&text_color=ECECEC&bg_color=8A2BE2)

⭐️ From V2dha (https://github.com/V2dha)
