<p align="center">
 <h2 align="center">Welcome to my Profile</h2>
</p>

### Hello World 👋 I am [Tomás Costa](https://github.com/TomasCostaK)

<a href="https://www.linkedin.com/in/tomascostax/">
  <img align="left" alt="TomasCostaK LinkedIn" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>
<a href="https://youtube.com">
  <img align="left" alt="TomasCostaK Youtube" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/youtube.svg" />
</a>
<a href="https://medium.com">
  <img align="left" alt="TomasCostaK Medium" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/medium.svg"/>
</a>

<div>
  
<br />
<p>

- 🔭 I’m currently working on **a colorful way of listing my projects using VueJS**
- 🌱 I’m currently learning **VueJs, Django, ExpressJS, DiscordJS**
- 👯 If you have any projects you would like to colaborate, reach out to me.
- 💬 Ask me about **anything**
- ⚡ Fun fact: Currently using **Machine Learning** to predict if I will pursue Machine Learning.

</h4>
</div>

<br />

<div><p>My overview: </p></div>

![TomasCostaK's github stats](https://github-readme-stats.vercel.app/api?username=TomasCostaK&show_icons=true)
<br />

<!-- Optional Visitors badge: -->
![visitors](https://visitor-badge.laobi.icu/badge?page_id=TomasCostaK.TomasCostaK)

⭐️ From [TomasCostaK](https://github.com/TomasCostaK/TomasCostaK) 

<br />
