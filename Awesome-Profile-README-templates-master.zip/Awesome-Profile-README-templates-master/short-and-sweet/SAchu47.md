<h1 align="center">Hey there! I'm Sachin Vilas Nagane 👋 </h1>
<h3 align="center">🚀 Backend Developer | MERN Stack | Open Source ♥ | Devops | Competitive Programmer  🚀</h3>
<div>
<img width = "35%" align="right" alt="PIC" height="300px" src="https://www.pngitem.com/pimgs/m/4-42822_apple-tv-copy-developer-illustration-png-transparent-png.png" />
<div align="left"> 
  <h3> 👨🏻‍💻 About Me </h3>

  - 🤔 &nbsp; Exploring new technologies and developing software solutions and quick hacks.
  - 🎓 &nbsp; Studying Computer Science and Engineering.
  - 💼 &nbsp; I’m currently working on Full Stack Development projects.
  - 🌱 &nbsp; Learning more about Backend Architectures and Frontend Developement.
  - ✍️ &nbsp; Pursuing Competitive Programming and Gaming as hobbies/side hustles.  
</div> 
</div>

<div>
  <h3> 💻 Languages and Tools </h3>
  <p>
   <img src="https://media.giphy.com/media/3rCcV6sC1o2GY/giphy.gif" width="50"><img src="https://media3.giphy.com/media/ln7z2eWriiQAllfVcn/200w.webp" width="50"><img src="https://i.giphy.com/media/LMt9638dO8dftAjtco/200.webp"   width="50"><img src="https://i.giphy.com/media/eNAsjO55tPbgaor7ma/200w.webp" width="50"><img src="https://i.giphy.com/media/IdyAQJVN2kVPNUrojM/200.webp" width="50"><img src="https://media3.giphy.com/media/kdFc8fubgS31b8DsVu/giphy.webp" width="50"><img src="https://media.giphy.com/media/SU2ic3wTfuC6JhD1lA/giphy.gif" width="50"><img src="https://media.giphy.com/media/kH1DBkPNyZPOk0BxrM/giphy.gif" width="100"><img src="https://media.giphy.com/media/SsCYf6DRFJrOpP0IoM/giphy.gif" width="70">
  <p>
</div> 

⭐️ From [SAchu47](https://github.com/SAchu47)
