## Hello there, I'm Ismail Habibi 🌏
### I'm the FullStack Developer | Software Engineer | Internet Expert

### 🚀 About
- 🎓 Majoring in Computer Science (Class of 2020)  
- 👀 I'm currently focusing on **web** and **android development**
- ⚙️ I use daily: `.php`, `.js`, `.html`, `.css`.
- 🔭 I'm currently learning **Laravel & VueJS**
- 💬 Ask me about: everything especially about **tech, movies, series**
- **I** ❤️ **to think, learn, code, and customize everything**
- 🔥 On Progress Project: E-learning build with Laravel 7 

### 📫 Reach me
[![Twitter URL](https://img.shields.io/twitter/url?label=email&logo=gmail&style=social&url=http%3A%2F%2Fmailto%3Acontact.ismailhabibi%40gmail.com)](mailto:contact.ismailhabibi@gmail.com)
[![Twitter URL](https://img.shields.io/twitter/url?label=LinkedIn&logo=linkedin&style=social&url=https%3A%2F%2Fwww.linkedin.com%2Fin%2Fismailhabibi)](https://linkedin.com/in/ismailhabibi)
[![Twitter Follow](https://img.shields.io/twitter/follow/ismlhbb?style=social)](https://twitter.com/intent/follow?screen_name=ismlhbb)
[![Twitter URL](https://img.shields.io/twitter/url?label=Facebook&logo=Facebook&style=social&url=https%3A%2F%2Ffacebook.com%2Fismlhbb)](https://facebook.com/ismlhbb)
[![Twitter URL](https://img.shields.io/twitter/url?label=Instagram&logo=Instagram&style=social&url=https%3A%2F%2Finstagram.com%2Fismlhbb)](https://instagram.com/ismlhbb)
[![Twitter URL](https://img.shields.io/twitter/url?label=Line&logo=Line&style=social&url=http%3A%2F%2Fline.me%2Fti%2Fp%2F~ismlhbb)](http://line.me/ti/p/~ismlhbb)
[![Twitter URL](https://img.shields.io/twitter/url?label=Steam&logo=steam&style=social&url=https%3A%2F%2Fsteamcommunity.com%2Fid%2Fismlhbb)](https://steamcommunity.com/id/ismlhbb)
[![Twitter URL](https://img.shields.io/twitter/url?label=Telegram&logo=telegram&style=social&url=https%3A%2F%2Ft.me%2Fismlhbb)](https://t.me/ismlhbb)
[![Twitter URL](https://img.shields.io/twitter/url?label=letterboxd&logo=Letterboxd&style=social&url=https%3A%2F%2Fletterboxd.com%2Fismlhbb)](https://letterboxd.com/ismlhbb)
[![Twitter URL](https://img.shields.io/twitter/url?label=DeviantArt&logo=deviantart&logoColor=black&style=social&url=https%3A%2F%2Fdeviantart.com%2Fismlhbb)](https://deviantart.com/ismlhbb)
[![Reddit User Karma](https://img.shields.io/reddit/user-karma/combined/sinner98?style=social)](https://reddit.com/u/sinner98)

### ✨Visitors
[![ViewCount](https://views.whatilearened.today/views/github/ismlhbb/ismlhbb.svg?cache=remove)](#)
---
⭐️ From [ismlhbb](https://github.com/ismlhbb)
