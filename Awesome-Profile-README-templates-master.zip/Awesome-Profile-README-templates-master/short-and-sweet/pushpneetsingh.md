<h2> 𝐇𝐞𝐥𝐥𝐨 GEEKERS<img src="https://raw.githubusercontent.com/ABSphreak/ABSphreak/master/gifs/Hi.gif" width="30px"></h2>

[![Linkedin Badge](https://img.shields.io/badge/-Pushpneet_Singh-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/harshkumarkhatri/)](https://www.linkedin.com/in/pushpneet-singh-155a9015a/) 
[![Gmail Badge](https://img.shields.io/badge/-pushpneetsingh99@gmail.com-c14438?style=flat-square&logo=Gmail&logoColor=white&link=mailto:mailharshkhatri@gmail.com)](mailto:pushpneetsingh99@gmail.com)

<img align='center' src='https://user-images.githubusercontent.com/5713670/87202985-820dcb80-c2b6-11ea-9f56-7ec461c497c3.gif' width='200"'>

## 😃 Talk to me about!!

- Front-end development using **HTML, Javascript,CSS,Bootstrap, Vue JS**
- Backend development using **Node Js**
- Machine Learning
- Portfolio site: [Portfolio](https://pushpneetsingh.netlify.com/)

![github stats](https://github-readme-stats.vercel.app/api?username=PushpneetSingh&show_icons=true)

![visitors](https://visitor-badge.glitch.me/badge?page_id=PushpneetSingh.PushpneetSingh)

---

⭐️ From [PushpneetSingh](https://github.com/PushpneetSingh)
