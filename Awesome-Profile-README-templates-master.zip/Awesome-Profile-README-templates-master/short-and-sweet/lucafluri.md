<img align='right' src="https://github-readme-stats.vercel.app/api?username=lucafluri&show_icons=true">

### Hi there I'm Luca :lemon:

[![lucafluri.ch](https://img.shields.io/static/v1?label=lucafluri.ch&message=%20&color=yellow&logo=&style=flat-square&logoColor=white)](https://www.lucafluri.ch/)
[![Instagram](https://img.shields.io/static/v1?label=Instagram&message=%20&color=orange&logo=Instagram&style=flat-square&logoColor=white)](https://www.instagram.com/lucafluri/)
[![me@lucafluri.ch](https://img.shields.io/static/v1?label=me@lucafluri.ch&message=%20&color=red&logo=gmail&style=flat-square&logoColor=white)](mailto:me@lucafluri.ch)
  
  
👨‍💻 24 Years old Developer  
👨‍🎓 Studying Computer Science here in Switzerland  
🚧 **Current Project:** [Price Tracker](https://github.com/lucafluri/price_tracker)

⭐️ From [lucafluri](https://github.com/lucafluri)
