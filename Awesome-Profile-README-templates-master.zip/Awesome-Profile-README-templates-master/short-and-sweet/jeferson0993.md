<img src="https://raw.githubusercontent.com/jeferson0993/jeferson0993/master/header.svg" width="800" height="400">

#### <a href="">Social</a>
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/github.svg' alt='github' height='40'>](https://github.com/jeferson0993)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/linkedin.svg' alt='linkedin' height='40'>](https://www.linkedin.com/in/jeferson-ferreira-4a036b143/)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/codepen.svg' alt='codepen' height='40'>](https://codepen.io/jeferson0993)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/stackoverflow.svg' alt='stackoverflow' height='40'>](https://stackoverflow.com/users/11685875/jeferson-ferreira)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/icloud.svg' alt='website' height='40'>](http://www.jeferson.tk)  

#### <a href="">FrontEnd</a>
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/angularjs.svg' alt='angularjs' height='40'>](https://github.com/jeferson0993/jeferson0993-crud-angularjs-firebase)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/angular.svg' alt='angular' height='40'>](https://github.com/jeferson0993/AngularWorkShop)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/svelte.svg' alt='svelte' height='40'>](https://github.com/jeferson0993/crud-svelte-firebase)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/vue-dot-js.svg' alt='vuejs' height='40'>](https://github.com/jeferson0993/crud-vuejs-firebase)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/jquery.svg' alt='jquery' height='40'>](https://github.com/jeferson0993/jeferson0993-crud-angularjs-firebase)

#### <a href="">BackEnd</a>
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/java.svg' alt='java' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/php.svg' alt='php' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/node-dot-js.svg' alt='node' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/firebase.svg' alt='firebase' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/amazonaws.svg' alt='aws' height='40'>](#)

#### <a href="">Databases</a>
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/mariadb.svg' alt='mariadb' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/postgresql.svg' alt='postgres' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/mongodb.svg' alt='mongodb' height='40'>](#)

#### <a href="">Tools</a>
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/debian.svg' alt='debian' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/visualstudiocode.svg' alt='vscode' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/webstorm.svg' alt='webstorm' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/firefox.svg' alt='firefox' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/insomnia.svg' alt='insomnia' height='40'>](#)
[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/gitkraken.svg' alt='git' height='40'>](#)

<a href='https://archiveprogram.github.com/'><img src='https://raw.githubusercontent.com/acervenky/animated-github-badges/master/assets/acbadge.gif' width='40' height='40'></a> <a href='https://github.com/pricing'><img src='https://raw.githubusercontent.com/acervenky/animated-github-badges/master/assets/pro.gif' width='50' height='50'></a>

![GitHub stats](https://github-readme-stats.vercel.app/api?username=jeferson0993&show_icons=true)

![Profile Views](https://komarev.com/ghpvc/?username=jeferson0993&color=blue)

---

⭐️ From [jeferson0993](https://github.com/jeferson0993)
