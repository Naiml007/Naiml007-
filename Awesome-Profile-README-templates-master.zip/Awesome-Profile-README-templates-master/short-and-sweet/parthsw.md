### Hi there, I am Parth! 👋

I am an end-to-end JavaScript enthusiast with extensive experience in the product development lifecycle working in Medical & Telecom domain projects. I am interested in UI, UX, Web Performance, JavaScript, TypeScript, and all things related to Web.

- 🔭 I’m currently working on Angular and Node.js
- 👯 Would love to collaborate on anything related to Web
- 🌱 On a never-ending quest of learning
- 📫 Find me on: [https://parthsw.tech](https://parthsw.tech)
- ⚡️ Fun fact: An ardent Cricket follower

---

<p align="center">⭐️ From <a href="https://github.com/parthsw">@parthsw</a></p>
