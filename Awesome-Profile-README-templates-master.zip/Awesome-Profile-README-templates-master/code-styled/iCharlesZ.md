![head.png](https://raw.githubusercontent.com/iCharlesZ/FigureBed/master/img/readme-top.png)

Hi there, thanks for stopping by, this is **Charles Zhang**.

<img align='right' src="https://raw.githubusercontent.com/iCharlesZ/FigureBed/master/img/octocat.gif" width="230">

```javascript
const charles = {
    pronouns: "He" | "Him",
    askMeAbout: ["web dev", "tech", "game"],
    technologies: {
        frontEnd: {
            js: ["Vue", "React", "Angular"],
            css: ["bootstrap", "sass"]
        },
        backEnd: ["Java", "PHP"],
        databases: ["MySql", "oracle"],
    }
};
```

![iCharles's github stats](https://github-readme-stats.vercel.app/api?username=iCharlesZ&hide=contribs,prs&count_private=true&show_icons=true)

<a href="https://github.com/iCharlesZ">
  <img src="https://img.shields.io/github/followers/iCharlesZ">
</a>
<a href="https://github.com/iCharlesZ">
   <img src="https://komarev.com/ghpvc/?username=iCharlesZ">
</a>

![bottom.png](https://raw.githubusercontent.com/iCharlesZ/FigureBed/master/img/readme-bottom.png)

---

⭐️ From [@iCharlesZ](https://github.com/iCharlesZ)