````bash
> help --info
> A potterhead and greek mythology enthusianst who mainly programs in Java and has recently ventured out into Python. Is
> trying out ML to see what all the fuss is about and he might actually ❤ it. Likes solving problems on hackerrank.
> Currently an undergrad@DTU batch of '21 studying mathematics and computing engineering and teaching java and python
> to students at What After College.
````

````bash
> help --contact
> linkedin: anishsachdeva1998
> instagram: anish.sachdeva_
> github: anishLearnsToCode
> medium: @anishsachdeva
> mailto: anish_ [at] outlook.com
````

⭐ From [anishLearnsToCode](https://github.com/anishLearnsToCode)
