### Hi there 👋<h2> I'm Shivam</h2>

<img align='right' src="https://media.giphy.com/media/M9gbBd9nbDrOTu1Mqx/giphy.gif" width="230">

<h3> 👨🏻•💻 About Me </h3>



- 🤔 &nbsp; Exploring new technologies and developing software solutions and quick hacks.

- 🎓 &nbsp; Studying Computer Science and Engineering at IIIT Vadodara and coding stuffs.

- 🌱 &nbsp; Learning about Cloud Tech, Systems Design.

- ✍️ &nbsp; Pursuing Web Development as hobbies/side hustles.



<h3>🛠 Tech Stack</h3>



- 💻 &nbsp; Python | Java | C++ | C | MySQL

- 🌐 &nbsp; HTML | CSS | JavaScript | Bootstrap | ReactJS

<!--

- 🛢 &nbsp; MySQL | MongoDB

- 🔧 &nbsp; Git | Markdown | Selenium | Tidyverse

- 🖥 &nbsp; Illustrator| Photoshop | InDesign

-->



<h3>🛠 To Learn</h3>

- 🔧 &nbsp; AWS | Docker🐳 | Firebase | flask

<hr>



<br/><br/>

[![Shivam's GitHub Stats](https://github-readme-stats.vercel.app/api?username=shivam0110&show_icons=true)](https://github.com/shivam0110)

<br/>

<br/>

<img src="https://github.com/nirala69/nirala69/blob/master/70804f7e25b11f29db904f2fa7b4cd9d.gif" width="350" align='right'>

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=shivam0110&show_icons=true)

<br><br>



<hr>



<h3> 🤝🏻 Connect with Me </h3>

<br>



<p align="center">

<a href="https://shivammalpani.netlify.app/"><img alt="Website" src="https://img.shields.io/badge/shivammalpani.netlify.app-black?style=flat-square&logo=google-chrome"></a>

<a href="https://www.linkedin.com/in/shivam-malpani-47a379198/"><img alt="LinkedIn" src="https://img.shields.io/badge/LinkedIn-Shivam%20Malpani-blue?style=flat-square&logo=linkedin"></a>

<a href="https://www.instagram.com/i__disbalance/"><img alt="Instagram" src="https://img.shields.io/badge/Instagram-i__disbalance-black?style=flat-square&logo=instagram"></a>

<a href="mailto:shivammalpani111@gmail.com"><img alt="Email" src="https://img.shields.io/badge/Email-shivammalpani111@gmail.com-blue?style=flat-square&logo=gmail"></a>

</p>





![Visitor count](https://visitor-badge.laobi.icu/badge?page_id=shivam0110.shivam0110)   <img src="https://media.giphy.com/media/dxn6fRlTIShoeBr69N/giphy.gif" width="30">





<hr>



