## नमस्ते 🙏
[![Linkedin](https://img.shields.io/badge/-LinkedIn-222222?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/01naveenv/)](https://www.linkedin.com/in/01naveenv/)
[![](https://img.shields.io/badge/Telegram-naveenv01-blue)](https://t.me/naveenv01)
[![](https://img.shields.io/badge/Leetcode-naveenverma-brightgreen)](https://leetcode.com/naveenverma/)
[![](https://img.shields.io/badge/Gmail-01naveenv%40gmail.com-red)](https://mail.google.com/mail/u/0/?tab=km#inbox)

<p align="center"> 
  Visitor count<br>
  <img src="https://profile-counter.glitch.me/naveenverma1/count.svg" />
</p>



```javascript
const Naveen = {
    pronouns: "He" | "Him",
    code: ["Javascript", "Java"],
    askMeAbout: ["web dev", "tech", "app dev", "music", "eddie vedder", "chris cornell"],
    technologies: {
       mobileApp: ["Android App"],
       backEnd: {
            js: ["node", "express", "hapi"],
        },
        databases: ["mongo", "MySql", "sqlite"],
        misc: ["Firebase", "Socket.IO"]
    },
    architecture: ["microservices", "event-driven"],
    funFact: "There are two ways to write error-free programs; only the third one works"
};
```
[![Naveen's github stats](https://github-readme-stats.vercel.app/api?username=naveenverma1&show_icons=true&theme=merko&hide=["contribs","issues"])](https://github.com/naveenverma1)

<img src="https://media.giphy.com/media/LnQjpWaON8nhr21vNW/giphy.gif" width="60"> <em><b>I love connecting with different people</b> so if you want to say <b>hi, I'll be happy to meet you more!</b> :)</em>

⭐️ From [naveenverma1](https://github.com/naveenverma1)
