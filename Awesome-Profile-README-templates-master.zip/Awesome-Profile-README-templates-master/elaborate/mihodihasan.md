![Me](https://raw.githubusercontent.com/mihodihasan/mihodihasan/master/images/android.jpg)
# ***Mihodi H. Lushan***
![](https://img.shields.io/badge/Android-Developer-brightgreen) ![](https://img.shields.io/badge/Kotlin-Lover-blueviolet) ![](https://img.shields.io/badge/Java-Enthusiast-yellow) ![](https://img.shields.io/badge/Exp-4+yrs-red)
### Hi there, 👋

- 🔭 I’m currently working on Ride-sharing and Livestock-Marketplace
- 🌱 I’m currently learning Kotlin, Coroutines, Dagger, Hilt
- 🌱 I’m currently studying and researching about Design-Pattern
- 👯 I’m looking to collaborate on any open source Android Repo
- 💬 Ask me about Android
- 📫 mihodihasan@gmail.com
- 📫 01746955388 (WhatsApp)

⭐️ From [mihodihasan](https://github.com/mihodihasan)