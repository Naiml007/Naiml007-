### Hi there 👋

<!--
**jeelpatel1612/jeelpatel1612** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.
-->

- 🔭 I’m currently working on "memepedia" - a Wikipedia for memes.
- 🌱 I’m currently learning React Native🤓.
- 👯 I’m looking to collaborate on JavaScript projects🤝.
- 🤔 I’m looking for help with [TCS-CodeVita-practice-problems](https://github.com/akatsuki-org/TCS-CodeVita-practice-problems)🧾
- 💬 Ask me about anything😁.
- 📫 How to reach me: [⏬Social media](https://github.com/jeelpatel1612/jeelpatel1612#-social), [📧email me](mailto:jeelpdev@gmail.com?subject=[GitHub]%20Source%20profile)
- ⚡ Fun fact: I might be a simulation💻.
<!-- - 😄 Pronouns: -->

<br />

<!-- ![my github stats - light](https://github-readme-stats.vercel.app/api?username=jeelpatel1612) -->
![my github stats - dark](https://github-readme-stats.vercel.app/api?username=jeelpatel1612&show_icons=true&count_private=true&theme=dark)

<!-- TODO : Dev Metrics : https://github.com/anmol098/waka-readme-stats -->

<br />

### 🚀 Skills
<!-- char. for indicating : %20 🟢 ⚪ -->
![python](https://img.shields.io/badge/python%20🟢🟢🟢⚪⚪-%233776AB.svg?&style=flat-square&logo=python&logoColor=white)  
![javascript](https://img.shields.io/badge/javascript%20🟢🟢🟢🟢⚪-%23F7DF1E.svg?&style=flat-square&logo=javascript&logoColor=white&labelColor=black)  
![reactjs](https://img.shields.io/badge/react%20🟢🟢🟢🟢⚪-%233776AB.svg?&style=flat-square&logo=react&logoColor=white)  
![nodejs](https://img.shields.io/badge/nodejs%20🟢🟢🟢⚪⚪-%233776AB.svg?&style=flat-square&logo=nodejs&logoColor=white) <!-- TODO: upload icon -->  
![html](https://img.shields.io/badge/html%20🟢🟢🟢🟢⚪-%23239120.svg?&style=flat-square&logo=html5&logoColor=white)  
![css](https://img.shields.io/badge/css%20🟢🟢🟢🟢⚪-%23239120.svg?&style=flat-square&logo=css3&logoColor=white)  

<br />

<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/sass/sass.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/bootstrap/bootstrap.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/typescript/typescript.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png"></code>

<!-- reference : https://github.com/anuraghazra/github-readme-stats -->
[![Top Languages](https://github-readme-stats.vercel.app/api/top-langs/?username=jeelpatel1612)](https://github.com/anuraghazra/github-readme-stats)

### 🎮🕹 Games
<!-- TODO: get public links -->
[<img src="https://img.shields.io/badge/xbox-%23107C10.svg?&style=for-the-badge&logo=xbox&logoColor=white" />](https://jeel/)
[<img src="https://img.shields.io/badge/Steam-%23000000.svg?&style=for-the-badge&logo=steam&logoColor=white" />](https://jeel/)

<br />

### 👨👩 Social
<!--
reference : https://github.com/alexandresanlim/Badges4-README.md-Profile
-->
[<img src="https://img.shields.io/badge/linkedin-%230077B5.svg?&style=for-the-badge&logo=linkedin&logoColor=white" />](https://www.linkedin.com/in/jeel/)
[<img src="https://img.shields.io/badge/stackoverflow-%23FF5722.svg?&style=for-the-badge&logo=stackoverflow&logoColor=white" />](https://stackoverflow.com/users/story/10872163)
[<img src = "https://img.shields.io/badge/instagram-%23E4405F.svg?&style=for-the-badge&logo=instagram&logoColor=white">](https://www.instagram.com/__j_e_e_l__/)
[<img src = "https://img.shields.io/badge/facebook-%231877F2.svg?&style=for-the-badge&logo=facebook&logoColor=white">](https://www.facebook.com/USERNAME)
[<img src = "https://img.shields.io/badge/reddit-%23FF5722.svg?&style=for-the-badge&logo=reddit&logoColor=white">](https://www.reddit.com/user/__j_e_e_l__)
<a href="https://twitter.com/__j_e_e_l__"><img src="https://img.shields.io/twitter/follow/__j_e_e_l__?label=Twitter&style=social" alt="Twitter"></a>
<a href="https://github.com/jeelpatel1612"><img src="https://img.shields.io/github/followers/jeelpatel1612.svg?label=GitHub&style=social" alt="GitHub"></a>
<!-- [<img src="https://img.shields.io/badge/twitter-%231DA1F2.svg?&style=for-the-badge&logo=twitter&logoColor=white" />](https://twitter.com/__j_e_e_l__) -->

⭐️ From [jeelpatel1612](https://github.com/jeelpatel1612)