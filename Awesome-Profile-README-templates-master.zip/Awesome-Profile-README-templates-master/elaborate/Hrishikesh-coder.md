# 👋🏻 Hey,
<div align="center">
	<br>
	<img src="https://raw.githubusercontent.com/Aniket965/Aniket965/master/pacman.svg?sanitize=true" width="200" height="200">
</div>

# I am Hrishikesh , HRISHIKESH-CODER . 
## I am a programmer

- <img src="https://media.giphy.com/media/KAq5w47R9rmTuvWOWa/giphy.gif" width=50 height=50>  I know Python and I love to code in Python . I am proficient in Django, a web development framework. I also know a bit of machine learning and AI . <br>
- <img src="https://seeklogo.com/images/J/java-logo-7F8B35BAB3-seeklogo.com.png" width=50 height=50>  I also know Java and like coding in Java . 
- <img src="https://cdn.svgporn.com/logos/aws.svg" width=30 height=30>  I also like AWS, Amazon Web Services<br>
- <img src="https://media0.giphy.com/media/pylpD8AoQCf3CQ1oO2/giphy.gif" width=30 height=30>  I have built some projects and am planning to build some more.<br>

## My Tech Stack

<table>
  <tbody>
    <tr valign="top">
      <td width="25%" align="center">
	      <span><strong>Python</strong></span><br><br><br>
        <img height="100px" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Python-logo-notext.svg/1200px-Python-logo-notext.svg.png">
      </td>
      <td width="25%" align="center">
	      <span><strong>AWS</strong></span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/aws.svg">
      </td>
      <td width="25%" align="center">
        <span><strong>Java</strong></span><br><br><br>
        <img height="100px" src="https://upload.wikimedia.org/wikipedia/en/thumb/3/30/Java_programming_language_logo.svg/1200px-Java_programming_language_logo.svg.png">
      </td>
      <td width="25%" align="center">
        <span><strong>Django</strong></span><br><br><br>
        <img height="64px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRlHpEsRq4pIo4vTLAn24qGNwG41dFdXLJwsQ&usqp=CAU">
      </td>
     </tr>
    <tr valign="top">
      <td width="25%" align="center">
        <span><strong>CSS</strong></span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/css-3.svg">
      </td>
      <td width="25%" align="center">
        <span><strong>Html 5</strong></span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/html-5.svg">
      </td>
      <td width="25%" align="center">
        <span><strong>Git</strong></span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/git-icon.svg">
      </td>
      <td width="25%" align="center">
        <span><strong>Vs Code</strong></span><br><br><br>
        <img height="64px" src="https://cdn.svgporn.com/logos/visual-studio-code.svg">
      </td>
    </tr>

  </tbody>
</table>

![Hrishikesh's github stats](https://github-readme-stats.vercel.app/api/?username=hrishikesh-coder&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515)
<br>

  <a href="https://www.linkedin.com/in/hrishikesh-bhanja-9348a81b2/">
    <img align="left" alt="Jugal Bhatt | Linkedin" width="24px" src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Linkedin.svg" />
  </a>
  <a href="mailto:hrishipotter123@gmail.com">
    <img align="left" alt="Jugal Bhatt | Gmail" width="26px" src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Gmail.svg" />
  </a>
  
<br>

![VisitorCount](https://profile-counter.glitch.me/hrishikesh-coder/count.svg)

<br><br><br><br>

# THAT'S ME !

⭐️ From [Hrishikesh-coder](https://github.com/Hrishikesh-coder)
