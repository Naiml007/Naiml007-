<h1 align="center">👋 print("Olá, Mundo!") </h1> 

<a href="https://www.linkedin.com/in/maria-eduarda-de-azevedo-silva-a9a134191/" target="_blank"><img src="https://img.shields.io/badge/LinkedIn-%230077B5.svg?&style=flat-square&logo=linkedin&logoColor=white" alt="LinkedIn"><a href="https://open.spotify.com/user/6fgvmx4gtnl612cg0jjtyugps" target="_blank"><img src="https://img.shields.io/badge/Spotify-%231ED760.svg?&style=flat-square&logo=spotify&logoColor=white" alt="Spotify"></a><a href="https://twitter.com/ddt_azevedo" target="_blank"><img src="https://img.shields.io/badge/Twitter-%230077B5.svg?&style=flat-square&logo=twitter&logoColor=white" alt="Twitter"></a>


<p>
    Me chamo <strong>Maria Eduarda de Azevedo</strong> e atualmente sou acadêmica do curso de Ciências da Computação na Universidade Federal de Campina Grande (UFCG).
</p>
<h3>ℹ️ Informações gerais 👩‍💻 🏳️‍🌈</h3>
<strong>Meus pronomes</strong>: Ela/dela 👩
<strong>Pode me chamar de</strong>: Duda 🙂
<strong>De onde sou</strong>: Campina Grande - Paraíba - Brasil 🇧🇷

<h3>💻 Sobre tecnologias e afins... 🐍 🌐 👩‍💻</h3>
<h6>O que eu estou sempre aprendendo...</h6>
<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/1822/1822899.svg"/> <strong> Python </strong> (💙💙💙💙💙💙💙💙💙💙💙💙💙💙)

<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/919/919828.svg"/> <strong> JavaScript </strong> 

<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/919/919832.svg"/> <strong> TypeScript </strong> 

<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/226/226777.svg"/> <strong> Java </strong> 

<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/2807/2807253.svg"/> <strong> C </strong> 

<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/888/888859.svg"/> <strong> HTML5 </strong> 

<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/888/888847.svg"/> <strong> CSS3 </strong> 

<img height="30" src="https://www.flaticon.com/svg/static/icons/svg/919/919851.svg"/> <strong> React</strong> 

<img height="30" src="https://seeklogo.com/images/G/gatsby-logo-1A245AD37F-seeklogo.com.png"/> <strong> Gatsby</strong> 

<h3>🧐 Uma olhadinha no meu GitHub...</h3>
![Duda's GitHub stats](https://github-readme-stats.vercel.app/api?username=MariaEduardaDeAzevedo&show_icons=true&theme=radical)

- Se você gosta de Python tanto quanto eu, tenho uns repositórios com projetinhos muito legais que tratam de processamento de imagem, visão computacional, escrita em arquivos...
- Um dos meus favoritos é um corretor ortográfico que fiz durante a quarentena como projeto final de um curso de Linguagem C!
- Sempre estou colocando alguma coisa (aleatória ou não) por aqui.

⭐️ From [MariaEduardaDeAzevedo](https://github.com/MariaEduardaDeAzevedo)
