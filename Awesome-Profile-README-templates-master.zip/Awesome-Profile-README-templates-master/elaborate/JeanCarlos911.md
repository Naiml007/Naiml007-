⭐️ From [JeanCarlos911](https://github.com/JeanCarlos911)

<div align="center"><img alt="Banner | JeanCarlos911" src="https://i.imgur.com/34fiEUG.gif" /></div>

<p>
  <a>
    <img width="55%" align="right" alt="Onimur's github stats" src="https://github-readme-stats.vercel.app/api?username=JeanCarlos911&show_icons=true&hide_border=true" />
  </a>
  
  [![Top Programing languages](https://github-readme-stats.vercel.app/api/top-langs/?username=JeanCarlos911&layout=compact)](https://github.com/anuraghazra/github-readme-stats)
</p>

Welcome to my GitHub! I'm Jean Carlos, a systems engineering student. When I am not studying or programming, I play some music with my electric guitar, I like to read about personal and collective improvement, I love doing useful and fun things with programming, listening to different types of music, sharing with friends and much more.

### ✔️ I'm currently learning
- Kotlin (android development)
- Java (desktop apps)

### 😍 What i like to do:
- I like challenges, learning, LOGICAL PROBLEMS, helping, sharing and living !!!

### 💡 Goals for 2020:
- Finish my first app on android and publish it on play store
- Learn the basics of JavaScript, TypeScript
- Become skilled in Java, kotlin
- Grow as a person

### ⚡ Relevant achievement
- Enter the Francisco José de Caldas district university at a very low cost

### 🛠 Interested in:
- Desktop, mobile, fronted, devOps, games, designer.
