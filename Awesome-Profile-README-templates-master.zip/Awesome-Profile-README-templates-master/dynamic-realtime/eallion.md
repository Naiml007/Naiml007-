# Charles 'eallion' Chin 😃

- Full Stack Operator
- Working from home

Here are some ideas to get you started:

- 🔭 I’m currently working from home.
- 🌱 I’m currently learning English.
- 👯 I’m looking to collaborate on E-commerce.
- 🤔 I’m looking for help with Immigration.
- 💬 Ask me about you want.
- 📫 How to reach me: [Keybase](https://keybase.io/eallion)
- 😄 Pronouns: he / him
- ⚡ Fun fact: Fun fat.

[![Anurag's github stats](https://github-readme-stats.vercel.app/api?username=eallion&show_icons=true)](https://github.com/anuraghazra/github-readme-stats)

[![Twitter Badge](https://img.shields.io/badge/@eallion-1ca0f1?style=flat&labelColor=1ca0f1&logo=twitter&logoColor=white&link=https://twitter.com/eallion)](https://twitter.com/eallion) 
[![Blog Badge](https://img.shields.io/badge/eallion.com-FF4088?style=flat&labelColor=FF4088&logo=Hugo&logoColor=white&link=https://eallion.com/)](https://eallion.com/)
[![Gmail Badge](https://img.shields.io/badge/eallions@gmail.com-c14438?style=flat&logo=Gmail&logoColor=white&link=mailto:eallions@gmail.com)](mailto:eallions@gmail.com) 
![Visitors](https://visitor-badge.laobi.icu/badge?page_id=eallion.eallion)
![](https://komarev.com/ghpvc/?username=eallion&color=0366d6)

⭐️ From [eallion](https://github.com/eallion)
