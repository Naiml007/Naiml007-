<p align="center">
    <br>
    <samp>
        Hello there! I'm <b><a href="https://iiwowks.github.io/">iiwowks</a></b>.
        <br> I’m currently learning <b>vue.js & java</b>
        <br>
    </samp>
    <img align="middle"
        src="https://github-readme-stats.vercel.app/api?username=iiwowks&show_icons=true&theme=synthwave&hide_title=true" />
</p>

<details align="center">
    <summary> <b> <samp> Most used languanges </samp></b></summary>
    <samp>
        <img align="middle"
            src="https://github-readme-stats.vercel.app/api/top-langs/?username=iiwowks&hide_title=true&layout=compact" />
    </samp>
</details>

<details align="center">
    <summary> <b> <samp> Current project </samp></b></summary>

<a style="text-decoration: none" align="left" href="https://github.com/iiwowks/iiwowks.github.io">
        <img
            src="https://github-readme-stats.vercel.app/api/pin/?username=iiwowks&repo=iiwowks.github.io&show_owner=true" />
    </a>

<a align="left" href="https://github.com/iiwowks/vue-demo">
        <img src="https://github-readme-stats.vercel.app/api/pin/?username=iiwowks&repo=vue-demo&show_owner=true" />
</a>
</details>

<div align="center">
    <b> <samp> Contact me </samp></b>
    <br>

[![linkein](https://img.shields.io/badge/-LinkedIn-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/luiz-carlos-abbott-galvão-neto-21a93b148/)](https://www.linkedin.com/in/zhengjunan/)&nbsp; &nbsp; [![gmail](https://img.shields.io/badge/-Gmail-c14438?style=flat-square&logo=Gmail&logoColor=white&link=mailto:luiz7401@gmail.com)](mailto:s1029871348@gmail.com)&nbsp; &nbsp; [![leetcode](https://img.shields.io/badge/-Leetcode-FFA119?style=flat-square&logo=leetcode&logoColor=white)](https://leetcode-cn.com/u/iiwowks/)

</div>

⭐️ From [iiwowks](https://github.com/iiwowks)