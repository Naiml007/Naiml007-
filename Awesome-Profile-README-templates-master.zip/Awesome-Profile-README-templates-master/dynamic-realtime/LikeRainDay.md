<img align='right'  src="https://source.unsplash.com/random/500x100">


### Hi there I'm Houshuai :lemon:

[![csdn](https://img.shields.io/badge/-csdn-c14438?style=flat-square&logo=c&logoColor=white)](https://blog.csdn.net/qq_15807167)
[![Gmail Badge](https://img.shields.io/badge/-gmail-c14438?style=flat-square&logo=Gmail&logoColor=white&link=mailto:houshuai0816@gmail.com)](mailto:houshuai0816@gmail.com)

🚀Welcome to the rain planet🌎

![houshuai github stats](https://source.unsplash.com/random/800x500)


📊 **This week I spent my time on**

<img align='right'   width="300" src="https://github-readme-stats.vercel.app/api?username=LikeRainDay&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515">

<!--START_SECTION:waka-->
```text
Kotlin      1 hr 47 mins        ██████████░░░░░░░░░░░░░░░   39.80 % 
Other       1 hr 22 mins        ███████░░░░░░░░░░░░░░░░░░   30.65 % 
C++         24 mins             ██░░░░░░░░░░░░░░░░░░░░░░░   09.16 % 
YAML        21 mins             ██░░░░░░░░░░░░░░░░░░░░░░░   08.09 % 
Markdown    19 mins             █░░░░░░░░░░░░░░░░░░░░░░░░   07.22 %
```
<!--END_SECTION:waka-->


⭐️ From [LikeRainDay](https://github.com/LikeRainDay)