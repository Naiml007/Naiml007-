 🙋 | :octocat:
------------ | -------------
I am Wayne, an Engineer, a Senior Manager, an Amateur Software Developer, a Hacker, … and a curious person.  In my spare time, I enjoy reading, playing games, watching japanese animation, programming, learning japanese language and try new things. ⭐️ From [WayneChang65](https://github.com/WayneChang65)| ![github stats](https://github-readme-stats.vercel.app/api?username=WayneChang65&show_icons=true&line_height=30) <p align="center">27182818284590452353602874713526624977572470937</p>
