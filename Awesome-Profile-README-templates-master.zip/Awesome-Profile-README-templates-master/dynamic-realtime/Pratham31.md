<h2>Hello Traveler...🚶</h2>


<img src="https://github.com/Pratham31/Pratham31/blob/master/final.gif" height="430" width="400" align="right"></img>


## It's Prathamesh Giri here 👋
I am Open Source Contributor, AR/VR/XR Dev, Amazon Alexa Dev and Full stack Developer. I love experimenting with new technologies and building small projects.

- ☀️ Learning and Developing Machine Learning based projects in Python.
- ✍️ Writing tech blog posts over Internet.
- ➿ Contributing Open Source Projects.

## Things that I execute in free time ⚡ -  
  - In mean time, I create visual and artistic UI/UX on Adobe Xd.🌱
  - While Coding, Listening Music and developing useful code.⭐️
  - Just loved to Explore new Tech Stacks.💻
  - Learning Physics and getting knowledge about Space, Cosmos and Astronomy is My Night Job. 🌌 ☄️ 🔭
  - Always Willing to help (**Altruistic**). ✋ 


## My GitHub Stats(Only Public Contributions 😑) -
  
  ![Github Stats By Prathamesh](https://github-readme-stats.vercel.app/api?username=Pratham31&show_icons=true&title_color=fff&icon_color=79ff97&text_color=9f9f9f&bg_color=151515)  
</br>

## My Portfolio and Work 👀 -
### 1.[Personal Web](http://prathameshgiri.me/) 👦 </br>
### 2.[Portfolio](https://sites.google.com/view/prathamesh-giri/home) ✨
</br>

## Social Hangouts 💬 -

<a href="https://twitter.com/_Autodidactic">
  <img align="left" alt="Prathamesh Giri| Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />
</a>
<a href="https://www.linkedin.com/in/autodidactic/">
  <img align="left" alt="Linkedin" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>
<a href="https://prathamtalks.blogspot.com/">
  <img align="left" alt="Linkedin" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/blogger.svg" />
</a>
<a href="https://medium.com/@Oautodidactic">
  <img align="left" alt="Linkedin" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/medium.svg" />
</a>
<a href="https://stackoverflow.com/users/story/13827345">
  <img align="left" alt="StackOverflow" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.1.0/icons/stackoverflow.svg" />
</a>
</br>
</br>

### ⭐️ From [Pratham31](https://github.com/Pratham31)
 

