### Hi there, I'm WEGFan! 👋

<a href="https://github.com/WEGFan">
  <img src="https://github-readme-stats.vercel.app/api?username=WEGFan&show_icons=true" alt="WEGFan's GitHub Stats" />
</a>

### My latest projects

<a href="https://github.com/WEGFan/codestats-profile-readme">
  <img align="middle" src="https://github-readme-stats.vercel.app/api/pin/?username=WEGFan&repo=codestats-profile-readme" alt="codestats-profile-readme" />
</a>
<a href="https://github.com/WEGFan/Geometry-Dash-Menu-Music-Randomizer">
  <img align="middle" src="https://github-readme-stats.vercel.app/api/pin/?username=WEGFan&repo=Geometry-Dash-Menu-Music-Randomizer" alt="Geometry-Dash-Menu-Music-Randomizer" />
</a>

### Recently I'm coding in...

<a href="https://codestats.net/users/WEGFan">
  <img src='https://codestats-readme.wegfan.cn/history-graph/WEGFan?width=850&height=300&timezone=08:00&history_days=21&max_languages=9&language_colors=["3e4053","f15854","5da5da","faa43a","60bd68","f17cb0","b2912f","decf3f","b276b2","808080"]' alt="WEGFan's Code::Stats history graph" />
</a>

---

⭐️ From [WEGFan](https://github.com/WEGFan)
