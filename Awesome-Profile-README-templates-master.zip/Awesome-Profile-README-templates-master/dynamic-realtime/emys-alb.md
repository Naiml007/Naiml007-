### Hi there 🌈

<a href="https://www.linkedin.com/in/emilly-de-albuquerque-oliveira-59837118b/">
  <img align="left" alt="Emilly's LinkdeIn" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
</a>
<a href="https://twitter.com/emys_alb">
  <img align="left" alt="Emilly's Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@3.10.0/icons/twitter.svg" />
</a>

<img align="right" width="450px" alt="GIF" src="https://miro.medium.com/max/480/0*tWkX7jycteZn1qbC.gif" />
<br>

<br> My name is Emilly(she/her). I'm pursuing a Bachelor's degree in Computer Science. 
<br> 🔭 Currently learning about data science, frontend and how to play among us.
<br> 🌱 I am passionate about contribuing, being part of a community (that's why i'm in so many...) and music.
<br> ⚡ Recently my projects are kid-related, while I am studying I find something nice to do for them.
<br> For more info, you can visit my [porftolio](https://emys-alb.github.io/)

**Languages and Tools:**  
<code><img height="30" src="https://www.iconfinder.com/data/icons/logos-and-brands-adobe/512/267_Python-512.png"></code>
<code><img height="30" src="https://cdn.icon-icons.com/icons2/2108/PNG/512/javascript_icon_130900.png"></code>
<code><img height="30" src="https://www.flaticon.com/svg/static/icons/svg/226/226777.svg"></code>

![Emys's Stats](https://github-readme-stats.vercel.app/api?username=emys-alb&show_icons=true&theme=radical)

⭐️ From [Emys-alb](https://github.com/emys-alb)
