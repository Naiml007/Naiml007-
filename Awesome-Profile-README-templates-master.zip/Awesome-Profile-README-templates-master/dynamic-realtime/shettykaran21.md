## Hi, I'm Karan 👨‍💻

#### B.Tech. student at Vishwakarma Institute of Technology, Pune.
![](https://komarev.com/ghpvc/?username=shettykaran21&color=79b8ff)

<br />

<img src="https://raw.githubusercontent.com/shettykaran21/shettykaran21/master/vector.jpg" alt="karan-vector" height="300px" />


### 🌍 Let's Connect!

<table>
   <tr>
      <td>
         <a href="https://linkedin.com/shettykaran21">
            <img align="left" alt="shettykaran21 | Linkedin" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/linkedin.svg" />
         </a>
      </td>
      <td>
         <a href="https://twitter.com/shettykaran21">
            <img align="left" alt="shettykaran21 | Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />
         </a>
      </td>
   </tr>
</table>

<br />

### 🔧 Languages and Tools:

<table>
   <tr>
      <td>
         <img align="left" alt="Visual Studio Code" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/visual-studio-code/visual-studio-code.png" />
      </td>
      <td>
         <img align="left" alt="HTML5" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png" />
      </td>
      <td>
         <img align="left" alt="Css" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png" />
      </td>
      <td>
         <img align="left" alt="Sass" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/sass/sass.png" />
      </td>
      <td>
         <img align="left" alt="JavaScript" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png" />
      </td>
      <td>
         <img align="left" alt="React" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png" />
      </td>
      <td>
         <img align="left" alt="Git" width="26px" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png" />
      </td>
      <td>
         <img align="left" alt="GitHub" width="26px" src="https://raw.githubusercontent.com/github/explore/78df643247d429f6cc873026c0622819ad797942/topics/github/github.png" />
      </td>
      <td>
         <img align="left" alt="GitHub" width="26px" src="https://raw.githubusercontent.com/github/explore/78df643247d429f6cc873026c0622819ad797942/topics/cpp/cpp.png" />
      </td>
      <td>
         <img align="left" alt="Windows Terminal" width="26px" src="https://upload.wikimedia.org/wikipedia/commons/0/01/Windows_Terminal_Logo_256x256.png" />
      </td>
      <td>
         <h4>WSL2</h4>
      </td>
   </tr>
</table>

<br />

---

### 📈 Github Stats

<div>
  <img align="left" alt="shettykaran21's Github Stats" src="https://github-readme-stats.shettykaran21.vercel.app/api?username=shettykaran21&show_icons=true&hide_border=true&title_color=79b8ff&bg_color=24292e&text_color=79b8ff&hide=stars,issues"/>
</div>

<br />

[linkedin]: https://linkedin.com/in/shettykaran21
[twitter]: https://twitter.com/shettykaran21

<br />
<br />
<br />
<br />
<br />
<br />
<br />

⭐️From [shettykaran21](https://github.com/shettykaran21)