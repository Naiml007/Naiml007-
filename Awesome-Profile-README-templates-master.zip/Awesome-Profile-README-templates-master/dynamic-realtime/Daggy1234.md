
### It's a me Daggy

![Discord](https://img.shields.io/discord/491175207122370581?color=black&label=Discord&logo=discord) ![](https://img.shields.io/endpoint?url=https://dev.discordprofiles.me/api/badge/vscode/491174779278065689) 

----

A high schooler from India with a passion for full stack development.I love python and Js seems to be my new love. 

-----

Skills:

- Web Develpment with React.js
- Machine learning with Sckit-learn
- API with FastAPI
- Discord bots with dpy
- Dockerizing Apps

-----
<a href="https://github.com/Daggy1234">
  <img src="https://komarev.com/ghpvc/?username=Daggy1234&style=flat-square" />
</a>


***

<a href="https://github.com/Daggy1234">
  <img src="https://github-readme-stats.vercel.app/api?username=Daggy1234&show_icons=true&hide_border=true" />
</a>

---

<a href="https://github.com/Daggy1234">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Daggy1234&layout=compact" />
</a>


Feel free to chat with me on discord.

-----


Have a Great Day!

⭐️ From [Daggy1234](https://github.com/Daggy1234)
