### Hi there, I'm JiangZhiguo 👨‍💻

[📧](jiangzhiguo2010@live.com)

> a frontEnd engineer(Full Stack)

#### 📍 Currently base at: Beijing, China

#### 💼 Currently working as: Tomorrow Wormhole at [Newsdog](https://www.newsdogapp.com/)

#### 👨🏻‍💻 Currently working on:

<a src="https://www.javascript.com/"><img src="https://img.icons8.com/color/48/000000/javascript.png"/></a>
<a src="https://reactjs.org/"><img src="https://img.icons8.com/color/48/000000/react-native.png"/></a>
<a src="https://www.typescriptlang.org/"><img src="https://img.icons8.com/color/48/000000/typescript.png"/></a>
<a src="https://nodejs.org/"><img src="https://img.icons8.com/color/48/000000/nodejs.png"/></a>
<a src="https://www.mongodb.com/"><img src="https://img.icons8.com/color/48/000000/mongodb.png"/></a>
<a src="https://www.docker.com/"><img src="https://img.icons8.com/color/48/000000/docker.png"/></a>
<a src="https://visualstudio.microsoft.com/"><img src="https://img.icons8.com/color/48/000000/visual-studio.png"/></a>
<a src="https://www.npmjs.com/"><img src="https://img.icons8.com/color/48/000000/npm.png"/></a>
<a src="https://getbootstrap.com/"><img src="https://img.icons8.com/color/48/000000/bootstrap.png"/></a>
<a src="https://github.com/"><img src="https://img.icons8.com/color/48/000000/github--v1.png"/></a>
<a src="https://www.w3schools.com/css/"><img src="https://img.icons8.com/color/48/000000/css3.png"/></a>
<a src="https://www.w3schools.com/html/"><img src="https://img.icons8.com/color/48/000000/html-5.png"/></a>

#### Currently organizations:

- [tmrwh](https://github.com/tmrwh)
- [jsany](https://github.com/jsany)

#### Bolg:

- 🔊 [book](https://github.com/Mr-jiangzhiguo/book)
- 👥 [juejin](https://juejin.im/user/5bbc81526fb9a05d07195d26)

#### My GitHub Stats(Only Personal Public Contributions 😑)

[![Jiangzhiguo's github stats](https://github-readme-stats.vercel.app/api?username=Mr-jiangzhiguo&show_icons=true)](https://github.com/anuraghazra/github-readme-stats)

⭐️ From [Mr-jiangzhiguo](https://github.com/Mr-jiangzhiguo)

<!--
**Mr-jiangzhiguo/Mr-jiangzhiguo** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
