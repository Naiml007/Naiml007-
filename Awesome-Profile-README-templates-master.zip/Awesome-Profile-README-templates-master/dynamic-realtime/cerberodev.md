![me](https://firebasestorage.googleapis.com/v0/b/cerberodev-cf89d.appspot.com/o/banner.png?alt=media&token=2446e47d-db03-48cf-adbd-1a492a6f5273)

<h1 align="center">Hi 👋, I'm Pierre Guillen</h1>
<h3 align="center">Flutter Developer, from Perú</h3>

<p align="center">
   <a href="https://youtube.com/cerberodev" target="_blank" style='margin-right:4px'>
    <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/youtube.svg" alt="cerberodev" width="48px" height="48px" />
  </a>
  <a href="https://twitter.com/cerberodev" target="_blank">
    <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/twitter.svg" alt="cerberodev" width="48px" height="48px" />
  </a>
  <a href="https://fb.com/cerberodev" target="_blank">
    <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/facebook.svg" alt="cerberodev" width="48px" height="48px" />
  </a>
  <a href="https://instagram.com/cerberodev" target="_blank">
    <img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/instagram.svg" alt="cerberodev" width="48px" height="48px" />
  </a>
</p>

<h3 align="center">My latest videos on  <a href="https://youtube.com/cerberodev" target="_blank">my Youtube Channel</a></h3>

<div align="center">

<a href='https://youtu.be/SBw98tYercQ' target='_blank'>
  <img width='30%' src='https://img.youtube.com/vi/SBw98tYercQ/mqdefault.jpg' alt='Flutter Meetup' />
</a>
<a href='https://youtu.be/XY3xpb5wLec' target='_blank'>
  <img width='30%' src='https://img.youtube.com/vi/XY3xpb5wLec/mqdefault.jpg' alt='Workshop Flutter + Firebase #1 2020 clase 01' />
</a>
<a href='https://youtu.be/aprSJZ29Wos' target='_blank'>
  <img width='30%' src='https://img.youtube.com/vi/aprSJZ29Wos/mqdefault.jpg' alt='#FlutterDayMeetups Managua - FlutterNi' />
</a>
<a href='https://youtu.be/rRmXWUoqWas' target='_blank'>
  <img width='30%' src='https://img.youtube.com/vi/rRmXWUoqWas/mqdefault.jpg' alt='GDG Arequipa - Meetup Firebase 2020' />
</a>
<a href='https://youtu.be/SSuLwKNaU_8' target='_blank'>
  <img width='30%' src='https://img.youtube.com/vi/SSuLwKNaU_8/mqdefault.jpg' alt='FlutterDay Perú' />
</a>
<a href='https://youtu.be/DfA_SV7w0jA' target='_blank'>
  <img width='30%' src='https://img.youtube.com/vi/DfA_SV7w0jA/mqdefault.jpg' alt='Flutter Peru, 2do meetup online!' />
</a>
</div>

<div align="center">
<p align="center">
  <img src="https://raw.githubusercontent.com/github/explore/cebd63002168a05a6a642f309227eefeccd92950/topics/flutter/flutter.png" alt="flutter" width="48px" height="48px"/>
  <img src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/dart/dart.png" alt="dart" width="48px" height="48px"/>
  <img src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/firebase/firebase.png" alt="firebase" width="48px" height="48px"/>
  
</p>
</div>

<p align="center">
<img src="https://github-readme-stats.vercel.app/api?username=cerberodev">
</p>


